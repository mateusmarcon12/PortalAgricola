<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Avalicaointerna extends Model
{
    //
    protected $fillable = [
        'idusuario','nota',
    ];
}
