<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Conversa extends Model
{
    //
        protected $fillable = [
        'titulo','idusuario1','idusuario2',
    ];
}
