<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Recomendacao extends Model
{
    //
    protected $fillable = [
      'idrecomendante','idrecomendado','idanuncio',
         ];
}
