<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-body">
                  <?php $__currentLoopData = $ende; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $end): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="PATCH" enctype="multipart/form-data" action="<?php echo e(route('end.update',$end->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <h6>Endereço</h6>
                            <div class="form-group row">
                                <label for="pais" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pais')); ?></label>

                                <div class="col-md-6">
                                    <select name="pais">
                                        <option value="76">Brasil</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Estado')); ?></label>

                                <div class="col-md-6">
                                    <select name="estado">

                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($rows->uf_codigo == $end->iduf): ?>
                                            <option value="<?php echo e($rows->uf_codigo); ?>" selected><?php echo e($rows->uf_descricao); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($rows->uf_codigo); ?>"><?php echo e($rows->uf_descricao); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cidade" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CEP - Cidade')); ?></label>

                                <div class="col-md-6">
                                    <select name="cidade">
                                        <?php $__currentLoopData = $cidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($row->cidade_codigo==$end->idcidade): ?>
                                                <option value="<?php echo e($row->cidade_codigo); ?>" selected><?php echo e($row->cidade_cep); ?> - <?php echo e($row->cidade_descricao); ?> </option>
                                            <?php else: ?>
                                                <option value="<?php echo e($row->cidade_codigo); ?>"><?php echo e($row->cidade_cep); ?> - <?php echo e($row->cidade_descricao); ?> </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="bairro" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Bairro')); ?></label>

                                <div class="col-md-6">
                                    <input id="bairro" type="text" class="form-control<?php echo e($errors->has('bairro') ? ' is-invalid' : ''); ?>" name="bairro" value="<?php echo e($end->bairro); ?>" required autofocus>

                                    <?php if($errors->has('bairro')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('bairro')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="rua" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Rua')); ?></label>

                                <div class="col-md-6">
                                    <input id="rua" type="text" class="form-control<?php echo e($errors->has('rua') ? ' is-invalid' : ''); ?>" name="rua" value="<?php echo e($end->rua); ?>" required autofocus>

                                    <?php if($errors->has('rua')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('rua')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="numero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Número')); ?></label>

                                <div class="col-md-6">
                                    <input id="titulo" type="text" class="form-control<?php echo e($errors->has('numero') ? ' is-invalid' : ''); ?>" name="numero" value="<?php echo e($end->numero); ?>" required autofocus>

                                    <?php if($errors->has('numero')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('numero')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="endobservacao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Observação sobre o Endereço')); ?></label>

                                <div class="col-md-6">
                                    <input id="observacao" type="text" class="form-control<?php echo e($errors->has('observacao') ? ' is-invalid' : ''); ?>" name="observacao" value="<?php echo e($end->observacao); ?>" required autofocus>

                                    <?php if($errors->has('observacao')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('observacao')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Salvar')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </div>            
            </div>                
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>