<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Cadastrar Endereço</div>
                <div class="card-body">
                        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('endereco.store')); ?>">
                            <?php echo csrf_field(); ?>
                            
                            <div class="form-group row">
                                <label for="pais" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pais')); ?></label>

                                <div class="col-md-6">
                                    <select name="pais">
                                        <option value="76">Brasil</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Estado')); ?></label>

                                <div class="col-md-6">
                                    <select name="estado">

                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                                <option value="<?php echo e($rows->uf_codigo); ?>"><?php echo e($rows->uf_descricao); ?></option>
                                         
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cidade" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CEP - Cidade')); ?></label>

                                <div class="col-md-6">
                                    <select name="cidade">
                                        <?php $__currentLoopData = $cidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                                <option value="<?php echo e($row->cidade_codigo); ?>"><?php echo e($row->cidade_cep); ?> - <?php echo e($row->cidade_descricao); ?> </option>
                                           
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="bairro" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Bairro')); ?></label>

                                <div class="col-md-6">
                                    <input id="bairro" type="text" class="form-control<?php echo e($errors->has('bairro') ? ' is-invalid' : ''); ?>" name="bairro" value="" required autofocus>

                                    <?php if($errors->has('bairro')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('bairro')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="rua" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Rua')); ?></label>

                                <div class="col-md-6">
                                    <input id="rua" type="text" class="form-control<?php echo e($errors->has('rua') ? ' is-invalid' : ''); ?>" name="rua" value="" required autofocus>

                                    <?php if($errors->has('rua')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('rua')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="numero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Número')); ?></label>

                                <div class="col-md-6">
                                    <input id="titulo" type="text" class="form-control<?php echo e($errors->has('numero') ? ' is-invalid' : ''); ?>" name="numero" value="" required autofocus>

                                    <?php if($errors->has('numero')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('numero')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="endobservacao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Observação sobre o Endereço')); ?></label>

                                <div class="col-md-6">
                                    <input id="observacao" type="text" class="form-control<?php echo e($errors->has('observacao') ? ' is-invalid' : ''); ?>" name="observacao" value="" required autofocus>

                                    <?php if($errors->has('observacao')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('observacao')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Salvar')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>  
                </div>            
            </div>                
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>