<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Anúncio</div>

                <div class="card-body">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="responsive">

                       
                              <h3>Título: <?php echo e($anu->titulo); ?></h3><br>
                                <h5><b>Detalhes</b></h5>
                                <p>
                                    Descrição: <?php echo e($anu->descricao); ?><br>
                                    Tipo: <?php echo e($anu->tipoanuncio); ?><br>
                                    Classificação: <?php echo e($classificacao->nome); ?> <br>
                                    Categoria: <?php echo e($categoria->nome); ?><br>
                                    Observação: <?php echo e($anu->observacao); ?><br>
                                    Data de Validade: <?php echo e(date( 'd/m/Y' , strtotime($anu->datavalidade))); ?><br>

                                </p>
                              <h5><b>Anunciante</b></h5>
                                <p>
                                    Nome: <?php echo e($user->name); ?> <a href="<?php echo e(route('usuario.exibeoutro', $anu->idanunciante)); ?>" class="btn btn-light">Ver Mais</a><br>
                                 
                                    E-mail:<?php echo e($user->email); ?> <br>
                                    

                                </p>
                              <h5><b>Endereço</b></h5>
                                <?php $__currentLoopData = $ende; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p>
                                    Rua <?php echo e($e->rua); ?>, nº <?php echo e($e->numero); ?>, bairro <?php echo e($e->bairro); ?>, cidade <?php echo e($e->cidade_descricao); ?> - <?php echo e($e->cidade_cep); ?> - <?php echo e($e->uf_descricao); ?> - <?php echo e($e->nome); ?>

                                </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-header">Fotos</div>
                          

                                                                <br><br>
                                    <div class="container">
                                        <div class="row justify-content-center">
                                            <div class="gallery">
                                                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <figure class="float-left">
                                                        <img align="center" class="img-responsive rounded" width="400" src="<?php echo e(url('storage/'.$f)); ?>"  alt="Anuncio">
                                                        
                                                    </figure>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                          
                            <br>
                            <?php if($anu->situacao == 'ativo'): ?>
                                <div class="card-header">Abrir negociação e enviar e-mail</div>
                                <br>
                                <p align="center">Responda este anúncio para iniciar uma negociação, e notificar o anunciante por e-mail.</p>
                                <br>
                                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('email.enviar', $anu->id)); ?>">
                                <?php echo csrf_field(); ?>
                                  
                                    <div class="form-group row">
                                        <label for="titulo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Assunto')); ?></label>

                                        <div class="col-md-6">
                                            <input id="assunto" type="text" class="form-control<?php echo e($errors->has('assunto') ? ' is-invalid' : ''); ?>" name="assunto" value="<?php echo e(old('assunto')); ?>" required autofocus>

                                            <?php if($errors->has('assunto')): ?>
                                                <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('assunto')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="sugerido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Vincule um dos seus anuncios a negociação')); ?></label>

                                        <div class="col-md-6">

                                            <select name="sugerido" id="sugerido" >
                                                    <option value="">nenhum</option>
                                                <?php $__currentLoopData = $meusanuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option value="<?php echo e($manu->id); ?>"> <?php echo e($manu->titulo); ?></option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>     
                                    <div class="form-group row">
                                            <label for="mensagem" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Mensagem')); ?></label>

                                            <div class="col-md-6">
                                                <textarea id="mensagem"  class="form-control<?php echo e($errors->has('mensagem') ? ' is-invalid' : ''); ?>" name="mensagem" value="<?php echo e(old('mensagem')); ?>" required autofocus>  </textarea>

                                                <?php if($errors->has('mensagem')): ?>
                                                    <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('mensagem')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-secondary">
                                                <?php echo e(__('Abrir negociação')); ?>

                                            </button>
                                        </div>
                                    </div>

                                </form>
                                <div class="card-header">Recomendar para um amigo</div>
                                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('recomendacao.guardar', $anu->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <p align="center">Recomende este anúncio para um de seus amigos que possa interessar-se!</p>
                                    <div class="form-group row">
                                        <br><br><br>
                                        <label for="recomendar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Amigo')); ?></label>

                                        <div class="col-md-6">

                                            <select name="recomendado" id="recomendado" >
                                                <?php $__currentLoopData = $amizades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option value="<?php echo e($ami->idamigo); ?>"> <?php echo e($ami->nome); ?></option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $amizades2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ami2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($ami2->idamigo); ?>"> <?php echo e($ami2->nome); ?></option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="col-md-6 offset-md-4">
                                                <button type="submit" class="btn btn-secondary">
                                                    <?php echo e(__('Enviar')); ?>

                                                </button>
                                        </div>

                                    </div>
                                </form>
                         <br>

                            <?php else: ?>
                                <h4 align="center">Este anúncio está em negociação!</h4>
                            <?php endif; ?>

<div class="card-header"></div><br>
                            <div align="center" class="align-content-center">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Voltar</a>
                            </div>
                        </div>
                    
                    

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>