<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-body">

                        <form class="form-inline my-2 my-lg-0" method="POST" enctype="multipart/form-data" action="<?php echo e(route('casamento.filtrar')); ?>">
                           <?php echo csrf_field(); ?>
                          <select name="tipo" class="form-control">
                              <option value="">Tipo</option>
                              <option value="Oferta">Ofertas</option>
                              <option value="Demanda">Demandas</option>
                          </select>  
                          
                          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Filtrar</button>
                        </form>
                </div>            
            </div>                
        </div>        



        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Anúncios compatíveis com os seus</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <?php if(isset($anu)): ?>
                        <div class="table-responsive">
                            <table id="example" class="table sortable table-hover">
                                <thead>
                                <tr>
                                    <th>Título</th>
                                    <th>Típo</th>
                                    <th>Descrição</th>
                                    <th>Anunciante</th>
                                    <th>Validade</th>
                                    <th>Meu Anúncio</th>
                                    <th>Grau</th>
                                    <th></th>
                                    <th></th>


                                </tr>
                                </thead>
                                <tbody>


                                <?php $__currentLoopData = $anu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <?php if($ticket->idof == Auth::user()->id): ?>

                                            <tr bgcolor="00FF7F">

                                            <td><?php echo e($ticket->titulodemanda); ?></td>
                                            <td><?php echo e($ticket->demandatipo); ?></td>
                                            <td><?php echo e($ticket->demandadescricao); ?></td>
                                            <td><?php echo e($ticket->demandadornome); ?></td>
                                            <td><?php echo e(date( 'd/m/Y' , strtotime($ticket->validadedemanda))); ?></td>
                                            <td><?php echo e($ticket->titulooferta); ?></td>
                                            <td><?php echo e($ticket->graucompatibilidade); ?></td>
                                            <td> <a href="<?php echo e(action('AnuncioController@show',$ticket->iddemanda)); ?>" class="btn btn-primary">Ver Mais</a> </td>

                                            </tr>

                                        <?php else: ?>
                                            <tr bgcolor="#98FB98">
                                            <td><?php echo e($ticket->titulooferta); ?></td>
                                            <td><?php echo e($ticket->ofertatipo); ?></td>
                                            <td><?php echo e($ticket->ofertadescricao); ?></td>
                                            <td><?php echo e($ticket->ofertantenome); ?></td>
                                            <td><?php echo e(date( 'd/m/Y' , strtotime($ticket->validadeoferta))); ?></td>
                                            <td><?php echo e($ticket->titulodemanda); ?></td>
                                            <td><?php echo e($ticket->graucompatibilidade); ?></td>
                                            <td> <a href="<?php echo e(action('AnuncioController@show',$ticket->idoferta)); ?>" class="btn btn-primary">Ver Mais</a> </td>
                                            </tr>
                                        <?php endif; ?>


                                    <tr>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                             <?php echo $anu->links(); ?>

                            <?php endif; ?>
                        </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>