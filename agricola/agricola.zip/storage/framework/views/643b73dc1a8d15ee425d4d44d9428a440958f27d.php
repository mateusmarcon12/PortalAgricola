<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Seja Bem Vindo! Faça login ou cadastre-se para explorar mais ferramentas do portal</div>

                    <div class="card-body">


                    <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(isset($anu)): ?>
                        <h3 align="center">Bem vindo ao AgriTroca - Portal de Trocas Agrícola!</h3>
                        <p>Aqui você encontra anúncios de ofertas e demandas de produtos e serviços agricolas.
                            Uma vez cadastrado no portal, você está apto a cadastrar anúncios, contatar outros anunciantes
                            podendo até adiciona-los a uma lista de amigos. Através desta rede de amigos, você e seus amigos do portal poderão
                            indicar anúncios uns aos outros.<br><br>
                            Também é possível avaliar os outros usuários, deixando uma nota e comentário em seu perfil. Através das avaliações
                            é possível identificar os melhores e mais confiáveis anunciantes do portal.</p>

                        <div class="card-header">Anúncios</div>
                        <div class="table-responsive">
                            <table class="table table table-hover">
                                <thead>
                                <tr>
                                    <th>Título</th>
                                    <th>Típo</th>
                                    <th>Descrição</th>
                                    <th>Anunciante</th>
                                    <th>Validade</th>
                                    



                                </tr>
                                </thead>
                                <tbody>


                                <?php $__currentLoopData = $anu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                        

                                          <?php if($ticket->tipoanuncio=='Oferta'): ?>
                                           <tr bgcolor="#98FB98">
                                          <?php else: ?>
                                            <tr bgcolor="#00FF7F">
                                          <?php endif; ?>

                                            <td><?php echo e($ticket->titulo); ?></td>
                                            <td><?php echo e($ticket->tipoanuncio); ?></td>
                                            <td><?php echo e($ticket->descricao); ?></td>
                                            <td><?php echo e($ticket->name); ?></td>
                                            

                                            <td><?php echo e(date( 'd/m/Y' , strtotime($ticket->validade))); ?></td>


                                            </tr>

                                    <tr>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                            <?php echo $anu->links(); ?>

                            <?php endif; ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>