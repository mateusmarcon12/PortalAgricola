<?php echo e($slot); ?>: <?php echo e($url); ?>

