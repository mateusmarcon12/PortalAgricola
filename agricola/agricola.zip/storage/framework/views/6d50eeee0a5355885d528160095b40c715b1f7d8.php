<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-10">
            <div class="card">
                <div class="card-body">

                    <form class="form-inline my-2 my-lg-0" method="POST" enctype="multipart/form-data" action="<?php echo e(route('anuncio.filtrarmeus')); ?>">
                        <?php echo csrf_field(); ?>
                        <select name="categoria" class="form-control">
                            <option value="">Categoria</option>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($cat->id); ?>"> <?php echo e($cat->nome); ?><br>
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="classificacao" class="form-control">
                            <option value="" >Classificação</option>
                            <?php $__currentLoopData = $classificacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($clas->id); ?>"> <?php echo e($clas->nome); ?><br>
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <select name="tipo" class="form-control">
                            <option value="">Tipo</option>
                            <option value="Oferta">Ofertas</option>
                            <option value="Demanda">Demandas</option>
                        </select>
                        <select name="situacao" class="form-control">
                            <option value="">Situação</option>
                            <option value="Ativo"> Ativo</option>
                            <option value="Inativo"> Inativo </option>
                            <option value="negociacao"> Em Negociação</option>

                        </select>
                        <input class="form-control mr-sm-2" name="titulo" type="search" placeholder="titulo" aria-label="Search">

                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Filtrar</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Meus Anúncios</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <?php if(isset($anu)): ?>
                        <div class="table-responsive">
                        <input class="form-control" id="myInput" type="text" placeholder="Pesquisar..">
                        <table id="example" class="table sortable table-hover">

                            <thead>
                            <tr>
                                <th>Título</th>
                                <th>Típo</th>
                                <th>Situação</th>

                                <th>Validade</th>
                                <th>Cadastro</th>
                                <th></th>
                                <th></th>
                                <th></th>

                            </tr>
                            </thead>
                            <tbody id="myTable">


                            <?php $__currentLoopData = $anu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                          <?php if($ticket->tipoanuncio=='Oferta'): ?>
                                           <tr bgcolor="#98FB98">
                                          <?php else: ?>
                                            <tr bgcolor="#00FF7F">
                                          <?php endif; ?>
                               
                                    <td><?php echo e($ticket->titulo); ?></td>
                                    <td><?php echo e($ticket->tipoanuncio); ?></td>
                                    <td><?php echo e($ticket->situacao); ?></td>

                                    <td><?php echo e(date( 'd/m/Y' , strtotime($ticket->datavalidade))); ?></td>
                                    <td><?php echo e(date( 'd/m/Y' , strtotime($ticket->created_at))); ?></td>
                                    <td> <a href="<?php echo e(action('AnuncioController@show',$ticket->id)); ?>" class="btn btn-primary">Detalhes</a></td>
                                    <td> <a href="<?php echo e(action('AnuncioController@edit',$ticket->id)); ?>" class="btn btn-primary">Editar</a> </td>
                                    <?php if(($ticket->situacao != 'inativo') && ($ticket->situacao != 'negociacao')): ?>
                                    <td> <a href="<?php echo e(action('AnuncioController@inativar',$ticket->id)); ?>" class="btn btn-primary">Inativar</a></td>
                                    <?php else: ?>
                                        <td></td>
                                    <?php endif; ?>
                                </tr>
                                <tr>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>
                         <?php echo $anu->links(); ?>

                        <?php endif; ?>
                        </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>