<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-header">Solicitações de amizade pendentes</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table table-hover">
                                    <thead>
                                    <tr>
                                        <th>Anunciante</th>
                                        <th>E-mail</th>
                                        <th></th>
                                        <th></th>


                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($soli->name); ?></td>
                                            <td><?php echo e($soli->email); ?></td>
                                            <td><a href="<?php echo e(route('solicitacao.aceitar', $soli->idsolicitacao)); ?>" class="btn btn-primary">Aceitar </a></td>
                                            <td><a href="<?php echo e(route('solicitacao.excluir', $soli->idsolicitacao)); ?>" class="btn btn-primary">Recusar</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    <div class="card-header">Meus amigos</div>
                        <div class="card-body">

                            <?php if(isset($amizades)): ?>
                            <div class="table-responsive">
                                <table class="table table table-hover">
                                    <thead>
                                    <tr>
                                        <th>Anunciante</th>
                                        <th>E-mail</th>
                                        <th></th>
                                        <th></th>

                                    </tr>
                                    </thead>
                                    <tbody>


                                    <?php $__currentLoopData = $amizades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>

                                                <td><?php echo e($ticket->nome); ?></td>
                                                <td><?php echo e($ticket->email); ?></td>
                                                <td><a href="<?php echo e(route('usuario.exibeoutro', $ticket->idanunciante)); ?>" class="btn btn-primary">Ver Mais</a></td>
                                                <td><a href="<?php echo e(route('amizade.excluir', $ticket->idamizade)); ?>" class="btn btn-primary">Excluir Amizade</a></td>

                                                </tr>

                                        <tr>

                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    <?php $__currentLoopData = $amizades2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>

                                            <td><?php echo e($ticket2->nome); ?></td>
                                            <td><?php echo e($ticket2->email); ?></td>
                                            <td><a href="<?php echo e(route('usuario.exibeoutro', $ticket2->idanunciante)); ?>" class="btn btn-primary">Ver Mais</a></td>
                                            <td><a href="<?php echo e(route('amizade.excluir', $ticket2->idamizade)); ?>" class="btn btn-primary">Excluir Amizade</a></td>

                                        </tr>

                                        <tr>

                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                                <?php endif; ?>

                        </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>