<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Perfil de Usuário</div>

                <div class="card-body">
                        <div class="table-responsive">

                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>
                              <h4><b> <?php echo e(Auth::user()->name); ?> </b><a href="<?php echo e(action('UserController@edit', Auth::user()->id)); ?>" class="btn btn-light">Editar</a>
                                  <a class="btn btn-light" href="<?php echo e(route('usuario.alterarsenha')); ?>">
                                    <?php echo e(__('Alterar Senha')); ?>

                                </a></h4>
                               <br>
                            <h5><b>Perfil</b></h5>
                                <p>
                                    E-mail: <?php echo e(Auth::user()->email); ?>

                                </p>
                              
                                <p>
                                    Sexo: <?php echo e(Auth::user()->sexo); ?> <br>
                                    <?php if(Auth::user()->cpf != null): ?>
                                        CPF: <?php echo e(Auth::user()->cpf); ?><br>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->cnpj != null): ?> 
                                        CNPJ: <?php echo e(Auth::user()->cnpj); ?>   
                                    <?php endif; ?>
                                    Telefone: <?php echo e(Auth::user()->telefone); ?> <br>
                                    Celular: <?php echo e(Auth::user()->celular); ?>

                                </p>
                               

                                <?php if(isset($endereco)): ?>
                                    <?php $__currentLoopData = $endereco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $end): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h5><b>Endereço</b> <a href="<?php echo e(action('EnderecoController@edit', $end)); ?>" class="btn btn-light">Editar Endereço</a></h5>
                                    <p>
                                        Rua <?php echo e($end->rua); ?>, nº <?php echo e($end->numero); ?>, bairro <?php echo e($end->bairro); ?>, cidade <?php echo e($end->cidade_descricao); ?> - <?php echo e($end->uf_descricao); ?>/<?php echo e($end->iso); ?>


                                    </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                                <?php if(empty($endereco)): ?>
                                    <h5>Endereço  <a href="<?php echo e(action('EnderecoController@create')); ?>" class="btn btn-light">Cadastrar Endereço</a></h5>
                                <?php endif; ?>
                                <div style="clear:both" class="card-header">Fotos</div>
                                <br><br>
                                    <div class="container">
                                        <div class="row justify-content-center">
                                            <div class="gallery">
                                                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <figure class="float-left">
                                                        <img align="center" class="img-responsive rounded" width="400" src="<?php echo e(url('storage/'.$f)); ?>"  alt="Anuncio">
                                                        
                                                    </figure>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                        </div>
                        <br>
                        <div style="clear:both">
                            <div class="justify-content-center">
                                <div align="center">
                                    <a class="btn btn-light" href="<?php echo e(route('fotos.excluir',Auth::user()->id)); ?>">
                                        <?php echo e(__('Excluir Fotos')); ?>

                                    </a>
                                </div>
                                <br>
                            </div>
                        </div>

                    <div class="table-responsive">
                    <div style="clear:both" class="container">
                        <div class="card-body">
                                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('foto.store')); ?>">
                                    <?php echo csrf_field(); ?>


                                    <div class="form-group row">
                                        <label for="Imagem" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Adicionar imagem')); ?></label>

                                        <div class="col-md-5">
                                             <input type="file" name="images" id="file">

                                        </div>
                                    </div>
                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-light">
                                                <?php echo e(__('Salvar')); ?>

                                            </button>
                                        </div>
                                    </div>


                                </form>
                        </div>
                    </div>
                        </div>
                        <div class="card-header"></div><br>
                 <br>
                 <h5 align="center">Deseja inativar sua conta no portal? <a href="<?php echo e(route('usuario.inativar', Auth::user()->id)); ?>" class="btn btn-danger">Inativar</a></h5>
                <br>
                            <div class="card-header"></div><br>
                            <br>
                <div align="center" class="align-content-center">
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Voltar</a>
                </div>

                <br>
                </div>
<!-- testes de galerias-->


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>