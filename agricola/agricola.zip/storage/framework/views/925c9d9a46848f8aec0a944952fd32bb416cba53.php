<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Anúncio</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <div class="table-responsive">

                            <?php if(($anu->situacao != 'inativo') && ($anu->situacao != 'negociacao')): ?>
                          
                                <h3>Título: <?php echo e($anu->titulo); ?> <a href="<?php echo e(action('AnuncioController@edit',$anu->id)); ?>" class="btn btn-light">Editar</a> <a href="<?php echo e(action('AnuncioController@inativar',$anu->id)); ?>" class="btn btn-light">Inativar</a></h3>
                            <?php else: ?>
                                <h3>Título: <?php echo e($anu->titulo); ?></h3>
                            <?php endif; ?>
                                <br>
                                <h5><b>Detalhes</b></h5>
                                <p>
                                    Descrição: <?php echo e($anu->descricao); ?><br>
                                    Situação: <?php if($anu->situacao != 'negociacao'): ?><?php echo e($anu->situacao); ?>

                                    <?php else: ?>
                                    Em negociação <i><br>     (quando o anúncio está em negociação o mesmo fica bloqueado para edição dos dados)</i>
                                    <?php endif; ?><br>
                                    Tipo: <?php echo e($anu->tipoanuncio); ?><br>
                                    Classificação: <?php echo e($classificacao->nome); ?> <br>
                                    Categoria: <?php echo e($categoria->nome); ?><br>
                                    Observação: <?php echo e($anu->observacao); ?><br>
                                    Data de Validade: <?php echo e(date( 'd/m/Y' , strtotime($anu->datavalidade))); ?><br>

                                </p>
                              <h5><b>Anunciante</b></h5>
                                <p>
                                    Nome: <?php echo e($user->name); ?> <br>
                                    E-mail: <?php echo e($user->email); ?> <br>

                                </p>
                              <h5><b>Endereço</b></h5>
                                <?php $__currentLoopData = $ende; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p>
                                    Rua <?php echo e($e->rua); ?>, nº <?php echo e($e->numero); ?>, bairro <?php echo e($e->bairro); ?>, cidade <?php echo e($e->cidade_descricao); ?> - <?php echo e($e->cidade_cep); ?> - <?php echo e($e->uf_descricao); ?> - <?php echo e($e->nome); ?>

                                </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div style="clear:both" class="card-header">Fotos</div>
                           
                                                                <br><br>
                                    <div class="container">
                                        <div class="row justify-content-center">
                                            <div class="gallery">
                                                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <figure class="float-left">
                                                        <img align="center" class="img-responsive rounded" width="400" src="<?php echo e(url('storage/'.$f)); ?>"  alt="Anuncio">
                                                        
                                                    </figure>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>

                          
                         <br> 
                        </div>
                        <div style="clear:both">
                            <div class="justify-content-center">
                                <div align="center">
                                    <a class="btn btn-light" href="<?php echo e(route('fotos.excluiranuncio', $anu->id)); ?>">
                                        <?php echo e(__('Excluir Fotos')); ?>

                                    </a>
                                </div>
                                <br>
                                <div>
                        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('foto.storeanuncio', $anu)); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row justify-content-center">
                            <div class="form-group row">
                                <label for="Imagem" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Adicionar imagem')); ?></label>

                                <div class="col-md-6">
                                    <input type="file" name="images" id="file">

                                </div>
                            </div>


                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-light">
                                        <?php echo e(__('Salvar')); ?>

                                    </button>
                                </div>
                            </div>
                        </div>
                        </form>
                        </div>
                                <div align="center" class="align-content-center">
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Voltar</a>
                                </div>
                    

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>