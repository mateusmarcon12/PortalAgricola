<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-md-10">

                <div class="card">
                    <div class="card-body">
                        <!--
                        <ul class="navbar-nav mr-auto">
                          <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Tipo de Anuncio
                            </a>

                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item" href="<?php echo e(route('anuncio.ofer')); ?>">Ofertas</a>
                              <a class="dropdown-item" href="<?php echo e(route('anuncio.dem')); ?>">Demandas</a>

                            </div>
                          </li>
                        </ul>
-->
                        <form class="form-inline my-2 my-lg-0" method="POST" enctype="multipart/form-data" action="<?php echo e(route('usuario.filtrar')); ?>">
                            <?php echo csrf_field(); ?>

                            <input class="form-control mr-sm-2" name="nome" type="search" placeholder="Nome" aria-label="Search">
                            <input class="form-control mr-sm-2" name="email" type="email" placeholder="E-mail" aria-label="Search">

                            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Filtrar</button>
                        </form>
                    </div>
                </div>
            </div>





            <div class="col-md-10">

                <div class="card">
                    <div class="card-header">Anunciantes do Portal</div>

                    <div class="card-body">

                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(isset($usuarios)): ?>
                        <div class="table-responsive">
                            <input class="form-control" id="myInput" type="text" placeholder="Pesquisar..">
                            <!--Ordenar:
                            <a href="/usuario/todos/id/?gender=e-mail">E-mail</a>-->
                            <table id="example" class="table table-hover sortable">
                                <thead>
                                <tr>
                                    <th data-firstsort="cresc">Anunciante</th>
                                    <th>E-mail</th>
                                    <th></th>
                                    <th></th>

                                </tr>
                                </thead>
                                <tbody id="myTable">


                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>

                                            <td><?php echo e($ticket->name); ?></td>
                                            <td><?php echo e($ticket->email); ?></td>
                                            <td><a href="<?php echo e(route('usuario.exibeoutro', $ticket->id)); ?>" class="btn btn-primary">Ver Mais</a></td>
                                            <td><a href="<?php echo e(route('solicitacao.store', $ticket->id)); ?>" class="btn btn-primary">Solicitar Amizade</a></td>

                                            </tr>

                                    <tr>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                            <?php echo $usuarios->links(); ?>

                            <?php endif; ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>

</script>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>