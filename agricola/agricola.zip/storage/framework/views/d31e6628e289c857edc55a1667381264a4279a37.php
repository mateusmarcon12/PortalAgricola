<h3>Portal de Trocas Agricolas</h3>

<h4>O seguinte usuário abriu negociação com você:
<?php echo e($remetente); ?></h4>

<h4>Vá até o portal e continue a negociação ou finalize. enquanto a negociação estiver em aberto, o seu anuncio não será exibido para os demais anunciantes.</h4>

<h4>Mensagem:</h4>
<p>
<?php echo e($mensagem); ?>

</p>
<?php if(isset($titulo)): ?>
<h4>O remetente sugeriu o seguinte anúncio:</h4>
Título: <?php echo e($titulo); ?> <br>
Validade: <?php echo e($validade); ?><br>
<?php endif; ?>
<p>Para responder a mensagem ao usuário envie e-mail para <?php echo e($remetente); ?></p>