<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Editar Anuncios</div>

                    <div class="card-body">


                        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('upd',$detanuncio->id)); ?>">
                            <?php echo csrf_field(); ?>
                        <h6>Dados  </h6>

                            <div class="form-group row">
                                <label for="titulo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Título')); ?></label>

                                <div class="col-md-6">
                                    <input id="titulo" type="text" class="form-control<?php echo e($errors->has('titulo') ? ' is-invalid' : ''); ?>" name="titulo" value="<?php echo e($detanuncio->titulo); ?>" required autofocus>

                                    <?php if($errors->has('titulo')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('titulo')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="categoria" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Situação')); ?></label>
                                <br>
                                <div class="col-md-6">

                                        <?php if($detanuncio->situacao == 'ativo'): ?>
                                            <input type="radio" name="situacao" value="ativo" checked> Ativo
                                            <input type="radio" name="situacao" value="inativo"> Inativo<br>
                                        <?php else: ?>
                                            <input type="radio" name="situacao" value="inativo" checked> Inativo
                                            <input type="radio" name="situacao" value="ativo"> Ativo<br>
                                        <?php endif; ?>

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="descricao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descrição')); ?></label>

                                <div class="col-md-6">
                                    <textarea id="descricao" rows="3" type="textarea" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" name="descricao" value="<?php echo e($detanuncio->descricao); ?>" required autofocus><?php echo e($detanuncio->descricao); ?></textarea>
                                    <?php if($errors->has('descricao')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('descricao')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="classificacao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo')); ?></label>
<br>
                                <div class="col-md-6">

                                     <select name="tipo" id="classificacaoSelect" onchange="verificarclassificacao()" >
                                       
                                    <?php $__currentLoopData = $classificacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($detanuncio->tipo == $class->id): ?>
                                            <option value="<?php echo e($class->id); ?>" selected=""> <?php echo e($class->nome); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($class->id); ?>"> <?php echo e($class->nome); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="categoria" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Categoria')); ?></label>
<br>
                                <div class="col-md-6">

                                    <select name="classe" id="categoria">
                                       
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cat->id == $detanuncio->classe): ?>
                                                <option value="<?php echo e($cat->id); ?>" selected=><?php echo e($cat->nome); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="quantidade" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Quantidade')); ?></label>

                                <div class="col-md-3">


                                    <input id="quantidade" type="number" class="form-control<?php echo e($errors->has('quantidade') ? ' is-invalid' : ''); ?>" name="quantidade" value="<?php echo e($detanuncio->quantidade); ?>" required autofocus>

                                    <?php if($errors->has('quantidade')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('quantidade')); ?></strong>
                                    </span>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="unidademedida" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Unidade de Medida')); ?></label>

                                <div class="col-md-6">
                                    <select name="unidademedida">
                                            <option value="<?php echo e($detanuncio->unidademedida); ?>" selected><?php echo e($detanuncio->unidademedida); ?></option>
                                            <option value="un">Un</option>
                                            <option value="kg">kg</option>
                                            <option value="kg">l</option>
                                            <option value="m²">m²</option>
                                            <option value="m³">m³</option>
                                            <option value="sacas">Sacas</option>

                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="observacao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Observações')); ?></label>

                                <div class="col-md-6">
                                    <textarea id="observacao" rows="3" type="textarea" class="form-control<?php echo e($errors->has('observacao') ? ' is-invalid' : ''); ?>" name="observacao" value="<?php echo e($detanuncio->observacao); ?>" required autofocus><?php echo e($detanuncio->observacao); ?></textarea>
                                    <?php if($errors->has('observacao')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('observacao')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="datavalidade" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Validade Anúncio')); ?></label>

                                <div class="col-md-4">
                                    <input id="datavalidade" type="date" class="form-control<?php echo e($errors->has('datavalidade') ? ' is-invalid' : ''); ?>" name="datavalidade" value="<?php echo e($detanuncio->datavalidade); ?>" required autofocus>

                                    <?php if($errors->has('datavalidade')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('datavalidade')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <h6>Endereço</h6>
                            <div class="form-group row">
                                <label for="pais" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pais')); ?></label>

                                <div class="col-md-6">
                                    <select name="pais">
                                        <option value="76">Brasil</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Estado')); ?></label>

                                <div class="col-md-6">
                                    <select name="estado" id="ufSelect" onchange="verificaruf()">

                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($rows->uf_codigo == $endereco->iduf): ?>
                                            <option value="<?php echo e($rows->uf_codigo); ?>" selected><?php echo e($rows->uf_descricao); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($rows->uf_codigo); ?>"><?php echo e($rows->uf_descricao); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cidade" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CEP - Cidade')); ?></label>

                                <div class="col-md-6">
                                    <select name="cidade" id="cidade">
                                        <!--<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($row->cidade_codigo==$endereco->idcidade): ?>
                                                <option value="<?php echo e($row->cidade_codigo); ?>" selected><?php echo e($row->cidade_cep); ?> - <?php echo e($row->cidade_descricao); ?> </option>
                                            <?php else: ?>
                                                <option value="<?php echo e($row->cidade_codigo); ?>"><?php echo e($row->cidade_cep); ?> - <?php echo e($row->cidade_descricao); ?> </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="bairro" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Bairro')); ?></label>

                                <div class="col-md-6">
                                    <input id="bairro" type="text" class="form-control<?php echo e($errors->has('bairro') ? ' is-invalid' : ''); ?>" name="bairro" value="<?php echo e($endereco->bairro); ?>" required autofocus>

                                    <?php if($errors->has('bairro')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('bairro')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="rua" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Rua')); ?></label>

                                <div class="col-md-6">
                                    <input id="rua" type="text" class="form-control<?php echo e($errors->has('rua') ? ' is-invalid' : ''); ?>" name="rua" value="<?php echo e($endereco->rua); ?>" required autofocus>

                                    <?php if($errors->has('rua')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('rua')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="numero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Número')); ?></label>

                                <div class="col-md-6">
                                    <input id="titulo" type="text" class="form-control<?php echo e($errors->has('numero') ? ' is-invalid' : ''); ?>" name="numero" value="<?php echo e($endereco->numero); ?>" required autofocus>

                                    <?php if($errors->has('numero')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('numero')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="endobservacao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Observação sobre o Endereço')); ?></label>

                                <div class="col-md-6">
                                    <input id="endobservacao" type="text" class="form-control<?php echo e($errors->has('endobservacao') ? ' is-invalid' : ''); ?>" name="endobservacao" value="<?php echo e($endereco->observacao); ?>" required autofocus>

                                    <?php if($errors->has('endobservacao')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('endobservacao')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Salvar')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<script>
   window.onload = function(){
        var x = document.getElementById("classificacaoSelect").value;
        var ar = <?php echo json_encode($categorias,JSON_PRETTY_PRINT) ?>;
        $("#categoria").empty();
        for (var i = 0; i < ar.length; i++) {
            if(x==ar[i].idclassificacao){
            $('#categoria').append('<option name="categoria" value="' + ar[i].id + '">' + ar[i].nome + '</option>');
        
            }

        }

        $()
        var uf = document.getElementById("ufSelect").value;
        var cidades = <?php echo json_encode($result,JSON_PRETTY_PRINT) ?>;
        var endereco = <?php echo json_encode($endereco,JSON_PRETTY_PRINT) ?>;
        
        $("#cidade").empty();
        for (var i = 0; i < cidades.length; i++) {
            
            if(uf==cidades[i].uf_codigo){
            
                
                if(endereco.idcidade == cidades[i].cidade_codigo){
                    $('#cidade').append('<option selected name="cidade" value="' + cidades[i].cidade_codigo + '">' +  cidades[i].cidade_descricao +' CEP: '+ cidades[i].cidade_cep+ '</option>');

                }
                else{
                    $('#cidade').append('<option name="cidade" value="' + cidades[i].cidade_codigo + '">' +  cidades[i].cidade_descricao +' CEP: '+ cidades[i].cidade_cep+ '</option>');
                }

               //console.log(cidades[i]); 
            }   
        }

    }

    function verificarclassificacao(){
        var x = document.getElementById("classificacaoSelect").value;
        var ar = <?php echo json_encode($categorias,JSON_PRETTY_PRINT) ?>;
        $("#categoria").empty();
        //$("#cidade").empty();
        for (var i = 0; i < ar.length; i++) {
        
            if(x==ar[i].idclassificacao){
                
                $('#categoria').append('<option value="' + ar[i].id + '">' + ar[i].nome + '</option>');
            
            }

        }
    }

    function verificaruf(){
        var x = document.getElementById("ufSelect").value;
        var cidades = <?php echo json_encode($result,JSON_PRETTY_PRINT) ?>;
        $("#cidade").empty();
        for (var i = 0; i < cidades.length; i++) {

            if(x==cidades[i].uf_codigo){
               $('#cidade').append('<option name="cidade" value="' + cidades[i].cidade_codigo + '">' + cidades[i].cidade_descricao +' CEP: '+ cidades[i].cidade_cep+ '</option>');
               console.log(cidades[i]); 
            }

        }
    }

</script>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>