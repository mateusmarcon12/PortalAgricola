<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Perfil de Usuário</div>

                <div class="card-body">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>
                        <div class="responsive">

                      
                              <h4><b>Anunciante: <?php echo e($user->name); ?></b></h4>
                               <br>
                            <h5><b>Perfil</b></h5>
                                <p>
                                    E-mail:<?php echo e($user->email); ?>

                                </p>
                              
                                <p>
                                    Sexo: <?php echo e($user->sexo); ?> <br>
                                    <?php if($user->cpf != null): ?>
                                        CPF: <?php echo e($user->cpf); ?><br>
                                    <?php endif; ?>
                                    <?php if($user->cnpj != null): ?> 
                                        CNPJ: <?php echo e($user->cnpj); ?>   
                                    <?php endif; ?>
                                    Telefone: <?php echo e($user->telefone); ?> <br>
                                    Celular: <?php echo e($user->celular); ?>

                                </p>
                               

                                <?php if(isset($endereco)): ?>
                                    <?php $__currentLoopData = $endereco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $end): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h6><b>Endereço</b> </h6>
                                    <p>
                                        Rua <?php echo e($end->rua); ?>, nº <?php echo e($end->numero); ?>, bairro <?php echo e($end->bairro); ?>, cidade <?php echo e($end->cidade_descricao); ?> - <?php echo e($end->uf_descricao); ?>/<?php echo e($end->iso); ?>


                                    </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 

                                <div style="clear:both" class="card-header">Fotos do Anunciante</div>
                                                                <br><br>
                                    <div class="container">
                                        <div class="row justify-content-center">
                                            <div class="gallery">
                                                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <figure class="float-left">
                                                        <img align="center" class="img-responsive rounded" width="400" src="<?php echo e(url('storage/'.$f)); ?>"  alt="Anuncio">
                                                        
                                                    </figure>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>

                              <div style="clear: both">
                                  <br>
                              <div style="clear:both" class="float-none col-md-12 card-header">Avaliações do Anunciante</div>

                                    <br>
                                    <h5 align="center">Este anunciante é classificado em média como nota: <?php echo e($media); ?></h5>
                                    <br>
                                <?php if(($negociacaos1>0)or($negociacaos2>0)): ?>
                                            <h5 align="center">Já negociou com este anunciate? Deixe sua avaliação e comentário!</h5>
                                        <br>

                                      <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('avaliacao.gravar', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>

                                                <div class="form-group row">
                                                    <label for="nota" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nota:')); ?></label>

                                                    <div class="col-md-6">
                                                        <label class="btn btn-secondary active"> 1 <input type="radio" name="nota" value="1"></label>
                                                            <label class="btn btn-secondary active"> 2<input type="radio" name="nota" value="2"></label>
                                                                <label class="btn btn-secondary active">  3<input type="radio" name="nota" value="3"></label>
                                                                    <label class="btn btn-secondary active"> 4<input type="radio" name="nota" value="4"></label>
                                                                        <label class="btn btn-secondary active">  5<input type="radio" name="nota" value="5"></label>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label for="comentario" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Comentário')); ?></label>

                                                    <div class="col-md-6">
                                                        <textarea id="comentario"  class="form-control<?php echo e($errors->has('comentario') ? ' is-invalid' : ''); ?>" name="comentario" value="<?php echo e(old('comentario')); ?>" required autofocus>  </textarea>

                                                        <?php if($errors->has('comentario')): ?>
                                                            <span class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('comentario')); ?></strong>
                                                    </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <div class="col-md-6 offset-md-4">
                                                        <button type="submit" class="btn btn-light">
                                                            <?php echo e(__('Enviar')); ?>

                                                        </button>
                                                    </div>
                                                </div>

                                       </form>
                                <?php endif; ?>

                        <br>
                        <?php if(isset($avaliacao)): ?>
                                <div class="table-responsive">
                                    <table class="table table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Avaliador</th>
                                                <th>Nota</th>
                                                <th>Comentário</th>
                                                <th>Data Avaliação</th>
                                            </tr>
                                        </thead>
                                        <tbody>


                                            <?php $__currentLoopData = $avaliacao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($a->avaliador); ?></td>
                                                    <td><?php echo e($a->nota); ?></td>
                                                    <td><?php echo e($a->comentario); ?></td>
                                                    <td><?php echo e(date( 'd/m/Y' , strtotime($a->datapost))); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                                  <p><i>*As avaliações aqui exibidas são de usuários que já realizaram transações com este anunciante</i></p>
                            <?php endif; ?>
                            </div>
                                <div align="center" class="align-content-center">
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Voltar</a>
                                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>