<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Negociação <?php echo e($neg->id); ?></div>

                <div class="card-body">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>

                        <div>
                            <?php if(isset($anuncio1)): ?>
                            <div>
                                <b>Anuncio:</b> <?php echo e($anuncio1->titulo); ?><br>
                                <b>Descrição:</b> <?php echo e($anuncio1->descricao); ?> <td> <a href="<?php echo e(action('AnuncioController@show',$anuncio1->id)); ?>" class="btn btn-secondary">Ver Mais</a>
                            </div>
                            <?php endif; ?>
                            <br>
                            <?php if(isset($anuncio2)): ?>
                            <div>
                                <b>Anuncio:</b> <?php echo e($anuncio2->titulo); ?><br>
                                <b>Descrição:</b> <?php echo e($anuncio2->descricao); ?> <td> <a href="<?php echo e(action('AnuncioController@show',$anuncio2->id)); ?>" class="btn btn-secondary">Ver Mais</a>
                            </div>
                            <?php endif; ?>
                            <br>
                        </div>
                        <div class="card-header">Mensagens</div>
                        <br>
                        <div>
                        <?php if(isset($mensagem)): ?>
                            <div class="col-md-12 justify-content-center">
                                <?php $__currentLoopData = $mensagem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="clear: both">
                                        <?php if($c->idremetente == Auth::user()->id): ?>
                                            <div class="col-md-6 float-right" align="justify">
                                               <i style="font-size:12px"> Mensagem de: <?php echo e($c->name); ?></i>
                                        <?php else: ?>
                                           <div class="col-md-6 float-left" align="justify">
                                               <i style="font-size:12px"> Mensagem de: <?php echo e($c->name); ?></i>

                                        <?php endif; ?>
                                               <p><?php echo e($c->mensagem); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        </div>
                        <div style="clear:both;">
                            <br>
                        
                        <div style="clear:both;">
                            <br>
                        <?php if($neg->situacao == 'ativa'): ?>
                        <div class="card-header">Adicionar mensagem</div>
                        <br>
                            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('negociacao.store', $neg->id)); ?>">
                            <?php echo csrf_field(); ?>
                                
                                <div class="form-group row">
                                        <label for="mensagem" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Mensagem')); ?></label>

                                        <div class="col-md-6">
                                            <textarea id="mensagem"  class="form-control<?php echo e($errors->has('mensagem') ? ' is-invalid' : ''); ?>" name="mensagem" value="<?php echo e(old('mensagem')); ?>" required autofocus>  </textarea>

                                            <?php if($errors->has('mensagem')): ?>
                                                <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('mensagem')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-secondary">
                                            <?php echo e(__('Enviar')); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        
                        <div class="card-header">Finalizar negociação</div>
                        <br>
                            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('negociacao.finalizar', $neg->id)); ?>">
                            <?php echo csrf_field(); ?>
                              
                                <div class="form-group row">
                                    <label for="titulo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Resultado da negociação:')); ?></label>

                                    <div class="col-md-6">
                                                <label class="btn btn-secondary active"> Sucesso <input type="radio" name="nota" value="Sucesso" checked=""></label>
                                                    <label class="btn btn-secondary active"> Insucesso<input type="radio" name="nota" value="Insucesso"></label>
                                                
                                    </div>
                                </div>   
                                <div class="form-group row">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-secondary">
                                            <?php echo e(__('Salvar')); ?>

                                        </button>
                                    </div>
                                </div>
                                <i>Marcando a opção sucesso, os anuncios serão inativados. Marcando a opção insucesso os anúncios serão reativados e exibidos para os demais usuários</i>
                            </form>
                        <?php else: ?>
                            <h3 align="center">Negociação Finalizada</h3>
                            <h4 align="center">
                                Resolução:
                                <?php if($neg->resultado == 'sucesso'): ?>
                                    Sucesso
                                <?php else: ?>
                                    Insucesso
                                <?php endif; ?>
                            </h4>
                        <?php endif; ?>

                            <div align="center" class="align-content-center">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Voltar</a>
                            </div>
                        </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>