    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-body">

                        <form class="form-inline my-2 my-lg-0" method="POST" enctype="multipart/form-data" action="<?php echo e(route('negociacao.filtrar')); ?>">
                           <?php echo csrf_field(); ?>

                          <select name="situacao" class="form-control">
                              <option value="">Situação</option>
                              <option value="ativa">Em andamento</option>
                              <option value="inativa">Finalizada</option>

                          </select>  
                          <select name="resolucao" class="form-control">
                              <option value="">Resolução</option>
                              <option value="sucesso">Sucesso</option>
                              <option value="insucesso">Insucesso</option>
                          </select>  
                          
                          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Filtrar</button>
                          
                        </form>
                          <i style="clear:both"><br>Selecionando uma resolução o campo "situação" será ignorado</i>
                </div>            
            </div>                
        </div>

        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Suas Negociações</div>

                <div class="card-body">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>

                        
                        <div class="table-responsive">
                        <input class="form-control" id="myInput" type="text" placeholder="Pesquisar..">
                        <table id="example" class="table sortable table-hover">
                            <thead>
                            <tr>
                                <th>Negociação</th>
                                <th>Negociante</th>
                                <th>Situação</th>
                                <th>Resolução</th>
                                <th></th>


                            </tr>
                            </thead>
                            <tbody id="myTable">

                            <?php if(isset($negociacaos)): ?>
                            <?php $__currentLoopData = $negociacaos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    
                                    <td><?php echo e($ticket->idnegociacao); ?></td>
                                   <?php if($ticket->idanunciante1 == Auth::user()->id): ?>
                                        <td><?php echo e($ticket->nomeanunciante2); ?></td>
                                   <?php elseif($ticket->idanunciante2 == Auth::user()->id): ?>
                                        <td><?php echo e($ticket->nomeanunciante1); ?></td>
                                   <?php endif; ?>
                                    <?php if($ticket->situacaonegociacao == 'inativa'): ?>
                                        <td>Finalizada</td>
                                    <?php else: ?>
                                        <td>Em andamento</td>
                                    <?php endif; ?>
                                    <?php if($ticket->resultadonegociacao!=null): ?>
                                        <td><?php echo e($ticket->resultadonegociacao); ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                    <?php endif; ?>
                                     <td> <a href="<?php echo e(action('NegociacaoController@show',$ticket->idnegociacao)); ?>" class="btn btn-primary">Ver mais</a></td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            </tbody>
                        </table>
                            <?php echo $negociacaos->links(); ?>

                        </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function() {
    $('#example').DataTable();
} );


</script>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>