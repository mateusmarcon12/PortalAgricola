<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Cadastrar '.$nomeanuncio)); ?></div>

                    <div class="card-body">

                        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route($tipoanuncio)); ?>">
                            <?php echo csrf_field(); ?>
                            <h6>Dados <?php echo e($nomeanuncio); ?></h6>
                            <div class="form-group row">
                                <label for="titulo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Título')); ?></label>

                                <div class="col-md-6">
                                    <input id="titulo" type="text" class="form-control<?php echo e($errors->has('titulo') ? ' is-invalid' : ''); ?>" name="titulo" value="<?php echo e(old('titulo')); ?>" required autofocus>

                                    <?php if($errors->has('titulo')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('titulo')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Imagem" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Imagem')); ?></label>

                                <div class="col-md-6">
                                    <input type="file" name="images" id="file">

                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="descricao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descrição')); ?></label>

                                <div class="col-md-6">
                                    <textarea id="descricao" rows="3" type="textarea" class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>" name="descricao" value="<?php echo e(old('descricao')); ?>" autofocus>
                                    </textarea>
                                    <?php if($errors->has('descricao')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('descricao')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="classificacao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo')); ?></label>
<br>
                                <div class="col-md-6">

                                     <select name="tipo" id="classificacaoSelect" onchange="verificarclassificacao()" >
                                        <option value=""></option>
                                    <?php $__currentLoopData = $classificacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                        <option value="<?php echo e($class->id); ?>"> <?php echo e($class->nome); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="categoria" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Categoria')); ?></label>
                                <br>
                                <div class="col-md-6">

                                    <select name="categoria" id="categoria">

                                    </select>    
                                    <!-- <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <input type="radio" name="categoria" value="<?php echo e($cat->id); ?>"> <?php echo e($cat->nome); ?><br>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="quantidade" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Quantidade')); ?></label>

                                <div class="col-md-3">
                                    <input id="quantidade" type="number" class="form-control<?php echo e($errors->has('quantidade') ? ' is-invalid' : ''); ?>" name="quantidade" value="<?php echo e(old('quantidade')); ?>" required autofocus>

                                    <?php if($errors->has('quantidade')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('quantidade')); ?></strong>
                                    </span>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="unidademedida" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Unidade de Medida')); ?></label>

                                <div class="col-md-6">
                                    <select name="unidademedida">
                                            <option value="un">Unidade</option>
                                            <option value="kg">KG</option>
                                            <option value="kg">L</option>
                                            <option value="m²">M²</option>
                                            <option value="sacas">sacas</option>

                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="observacao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Observações')); ?></label>

                                <div class="col-md-6">
                                    <textarea id="observacao" rows="3" type="textarea" class="form-control<?php echo e($errors->has('observacao') ? ' is-invalid' : ''); ?>" name="observacao" value="<?php echo e(old('observacao')); ?>" autofocus>
                                    </textarea>
                                    <?php if($errors->has('observacao')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('observacao')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="datavalidade" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Validade Anúncio')); ?></label>

                                <div class="col-md-4">
                                    <input id="datavalidade" type="date" class="form-control<?php echo e($errors->has('datavalidade') ? ' is-invalid' : ''); ?>" name="datavalidade" value="<?php echo e(old('datavalidade')); ?>" required autofocus>

                                    <?php if($errors->has('datavalidade')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('datavalidade')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <h6>Endereço</h6>
                            <div class="form-group row">
                                <label for="pais" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pais')); ?></label>

                                <div class="col-md-6">
                                    <select name="pais">
                                        <option value="76">Brasil</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="estado" class="col-md-4 col-form-label text-md-right" ><?php echo e(__('Estado')); ?></label>

                                <div class="col-md-6">
                                    <select name="estado" id="ufSelect" onchange="verificaruf()">
                                            <option value="">
                                        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($rows->uf_codigo); ?>"><?php echo e($rows->uf_descricao); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cidade" class="col-md-4 col-form-label text-md-right"><?php echo e(__('CEP - Cidade')); ?></label>

                                <div class="col-md-6">
                                    <select name="cidade" id="cidade">
                                        <!--<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->cidade_codigo); ?>"><?php echo e($row->cidade_cep); ?> - <?php echo e($row->cidade_descricao); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="bairro" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Bairro')); ?></label>

                                <div class="col-md-6">
                                    <input id="bairro" type="text" class="form-control<?php echo e($errors->has('bairro') ? ' is-invalid' : ''); ?>" name="bairro" value="<?php echo e(old('bairro')); ?>" required autofocus>

                                    <?php if($errors->has('bairro')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('bairro')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="rua" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Rua')); ?></label>

                                <div class="col-md-6">
                                    <input id="rua" type="text" class="form-control<?php echo e($errors->has('rua') ? ' is-invalid' : ''); ?>" name="rua" value="<?php echo e(old('rua')); ?>" required autofocus>

                                    <?php if($errors->has('rua')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('rua')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="numero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Número')); ?></label>

                                <div class="col-md-6">
                                    <input id="titulo" type="text" class="form-control<?php echo e($errors->has('numero') ? ' is-invalid' : ''); ?>" name="numero" value="<?php echo e(old('numero')); ?>" required autofocus>

                                    <?php if($errors->has('numero')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('numero')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="endobservacao" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Observação sobre o Endereço')); ?></label>

                                <div class="col-md-6">
                                    <input id="endobservacao" type="text" class="form-control<?php echo e($errors->has('endobservacao') ? ' is-invalid' : ''); ?>" name="endobservacao" value="<?php echo e(old('endobservacao')); ?>" autofocus>

                                    <?php if($errors->has('endobservacao')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('endobservacao')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Salvar')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<script>
function verificarclassificacao(){
    var x = document.getElementById("classificacaoSelect").value;
    var ar = <?php echo json_encode($categorias,JSON_PRETTY_PRINT) ?>;
    $("#categoria").empty();
    for (var i = 0; i < ar.length; i++) {
    
        if(x==ar[i].idclassificacao){
            $('#categoria').append('<option name="categoria" value="' + ar[i].id + '">' + ar[i].nome + '</option>');
        
        }

    }
}

function verificaruf(){
    var x = document.getElementById("ufSelect").value;
    var cidades = <?php echo json_encode($result,JSON_PRETTY_PRINT) ?>;
    $("#cidade").empty();
    for (var i = 0; i < cidades.length; i++) {

        if(x==cidades[i].uf_codigo){
           $('#cidade').append('<option name="cidade" value="' + cidades[i].cidade_codigo + '">' + cidades[i].cidade_descricao +' CEP: '+ cidades[i].cidade_cep+ '</option>');
           console.log(cidades[i]); 
        }

    }
}
</script>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>