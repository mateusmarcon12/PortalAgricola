<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Imagens</div>

                    <div class="card-body">

                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(isset($files)): ?>
                            <div style="clear:both" class="row">
                                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row float-left col-md-6">
                                        <div style="width: 100%">
                                        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('fotos.apagar',Auth::user()->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" type="text" name="images" id="file" value="<?php echo e($f); ?>">
                                           <img class="img-responsive rounded float-left" width="100" src="<?php echo e(url('storage/'.$f)); ?>"  alt="Anuncio">

                                           <button type="submit" width="100" class="btn btn-danger">
                                                        <?php echo e(__('Excluir')); ?>

                                                    </button></td>


                                        </form>
                                        </div>
                                    </div>
                                    <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                            <div align="center" class="align-content-center">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Voltar</a>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>