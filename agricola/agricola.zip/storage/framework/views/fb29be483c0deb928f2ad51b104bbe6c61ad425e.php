<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row justify-content-center">

        <div class="col-md-10">

            <div class="card">
                <div class="card-header">Anúncios Sugeridos por Amigos</div>

                <div class="card-body">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>

                <div class="container">

                     <?php if(isset($recomendacoes)): ?>
                        <div class="table-responsive">
                            <table class="table table table-hover">
                                <thead>
                                <tr>
                                    <th>Título</th>
                                    <th>Anunciante</th>
                                    <th>E-mail</th>
                                    <th>Validade</th>
                                    <th>Recomendante</th>
                                    <th></th>
                                    <th></th>



                                </tr>
                                </thead>
                                <tbody>


                                <?php $__currentLoopData = $recomendacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>

                                                <td><?php echo e($anu->titulo); ?></td>
                                                <td><?php echo e($anu->nome); ?></td>
                                                <td><?php echo e($anu->anuemail); ?></td>
                                               


                                            <td><?php echo e(date( 'd/m/Y' , strtotime($anu->datavalidade))); ?></td>
                                            <td><?php echo e($anu->recomendante); ?></td>
                                            <td> <a href="<?php echo e(action('AnuncioController@show',$anu->idanuncio)); ?>" class="btn btn-primary">Ver Mais</a> </td>
                                            <td> <a href="<?php echo e(action('RecomendacaoController@excluir',$anu->idrecomendacao)); ?>" class="btn btn-primary">Excluir</a> </td>

                                            </tr>

                                    <tr>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                            <?php echo $recomendacoes->links(); ?>

                            <?php endif; ?>
                        </div>

                    <div align="center" class="align-content-center">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>